---
name: equalfi-amm
description: EqualFi protocol operations via session keys. Use when interacting with EqualFi Position Agents, executing AMM operations, managing session keys with @equalfi/ski, or querying position state on Base/ETH/Arbitrum Sepolia testnets.
---

# EqualFi Protocol Operations

This skill provides the addresses, ABIs, and procedures for interacting with the EqualFi protocol via session keys.

## First-Time Setup

Before executing any operations, ask the user:

> "Do you want to install @equalfi/ski (EqualFi Session Key Installer)? This is required to interact with the protocol via session keys."

If yes, run:

```bash
pnpm dlx @equalfi/ski
```

This will:
- Prompt for Position NFT ID
- Prompt for Entity ID (default: 7)
- Generate a session key
- Store it encrypted at `~/.openclaw/keys/equalfi/position-<id>.json`
- Print the session key address

After installation, use the helper scripts in `scripts/` for operations.

## Helper Scripts

All scripts output JSON. Use `--help` for usage.

### test-session.js
Verify session key is installed and working:
```bash
node scripts/test-session.js --token-id 1 --rpc https://sepolia.base.org
```

### get-tba.js
Get TBA address for a position:
```bash
node scripts/get-tba.js --token-id 1 --rpc https://sepolia.base.org
```

### query-position.js
Query position state and pool memberships:
```bash
node scripts/query-position.js --token-id 1 --pool-id 1 --rpc https://sepolia.base.org
```

### create-auction.js
Create AMM auction via session key:
```bash
node scripts/create-auction.js \
  --token-id 1 \
  --pool-a 1 --pool-b 2 \
  --reserve-a 1000000000000000000 \
  --reserve-b 1000000000000000000 \
  --duration-seconds 3600 \
  --fee-bps 30 \
  --fee-asset 0 \
  --rpc https://sepolia.base.org \
  --chain-id 84532
```

### roll-yield.js
Roll yield from pool to position:
```bash
node scripts/roll-yield.js \
  --token-id 1 \
  --pool-id 1 \
  --rpc https://sepolia.base.org \
  --chain-id 84532
```

## Networks

| Network | Chain ID | RPC |
|---------|----------|-----|
| Base Sepolia | 84532 | `https://sepolia.base.org` |
| ETH Sepolia | 11155111 | `https://ethereum-sepolia.publicnode.com` |
| Arbitrum Sepolia | 421614 | `https://sepolia-rollup.arbitrum.io/rpc` |

All contracts deployed to identical addresses across networks.

## Deployed Addresses

### Core

| Contract | Address |
|----------|---------|
| Diamond | `0x027c9ba58be0af69c990da55630d9042d067652b` |
| Position NFT | `0x560beed75ba42f99602f8786abc4700c8b4cb1c5` |
| Faucet | `0x1261959bc4a9094b360523b53f7c56af373881ee` |

### Modules

| Module | Address |
|--------|---------|
| Session Key Module | `0x43ac98fa18ca88ae37596eb667c70317bfa1bade` |
| AMM Skill Module | `0x402DfcF43f1e9a7101717A97322bfA621c6a7a47` |

### Derivative Tokens

| Token | Address |
|-------|---------|
| Option Token | `0x41846a120acA3A794E606f937f6245a92257CdF0` |
| Futures Token | `0xdE559E6DB58A64e70DCD6DD27D408e37756943A5` |

### Pool Underlyings

| Pool | Address |
|------|---------|
| Pool 1 | `0x6a2a2edd60050617b9508e6d11901e25627e05fd` |
| Pool 2 | `0xd066def718cfdf12a316ba108a4bed93052e504c` |
| Pool 3 | `0x70e40142899ab58fda999886d616c64b7a78719a` |
| Pool 4 | `0x3d461b43473d89fe4e544cd5aca3148c268eb298` |
| Pool 5 | `0x30f89ed1ce6a8d4ea6cdd47f5e657d52496baa82` |
| Pool 6 | `0x0000000000000000000000000000000000000000` (ETH) |

### Registries

| Registry | Address |
|----------|---------|
| Identity | `0x8004A818BFB912233c491871b3d84c89A494BD9e` |
| Reputation | `0x8004B663056A597Dffe9eCcC1965A193B7388713` |
| Validation | `0x8004Cb1BF31DAf7788923b405b754f57acEB4272` |

## Session Key Management

See `references/session-keys.md` for full @equalfi/ski documentation.

### Active Session Key

| Field | Value |
|-------|-------|
| Label | `position-1` |
| Address | `0x2aDA49FD896c61ec27D9135e51C3f423f8623D4A` |
| Entity ID | `7` |

### CLI Commands

```bash
# List keys
ski list

# Show metadata
ski show --label position-1 --json

# Test validation
ski test --label position-1 --rpc <rpc-url> --tba <tba-address> --module 0x43ac98fa18ca88ae37596eb667c70317bfa1bade
```

### Runtime API

```javascript
const { loadSessionWallet, executeWithRuntimeValidation } = require('@equalfi/ski');

const wallet = await loadSessionWallet('position-1');

await executeWithRuntimeValidation({
  rpcUrl: 'https://sepolia.base.org',
  tbaAddress: '<tba-address>',
  moduleAddress: '0x43ac98fa18ca88ae37596eb667c70317bfa1bade',
  entityId: 7,
  data: encodedCalldata,
  value: 0n,
  sessionWallet: wallet,
  chainId: 84532
});
```

## AMM Skill Operations

### createAuction

```javascript
const params = {
  positionId: tokenId,      // Must match TBA's bound NFT
  poolIdA: 1,
  poolIdB: 2,
  reserveA: amountA,
  reserveB: amountB,
  startTime: timestamp,
  endTime: timestamp,
  feeBps: 30,
  feeAsset: 0
};
```

### cancelAuction

```javascript
await cancelAuction(auctionId);
// Requires: policy.allowCancel == true
```

### rollYieldToPosition

```javascript
await rollYieldToPosition(tokenId, poolId);
```

## Position Monitoring

See `references/protocol-reference.md` for complete ABIs and query examples.

### Key Queries

```javascript
// Position state
diamond.getPositionState(tokenId, poolId)

// Pool memberships
diamond.getPositionPoolMemberships(tokenId)

// Session key policy
sessionKeyModule.getSessionKeyPolicy(tbaAddress, 7, sessionKeyAddress)

// Auction state
diamond.getAuction(auctionId)

// TBA address for position
diamond.computeTBAAddress(tokenId)
```

## Reference Files

- `references/protocol-reference.md` — Full ABIs, all addresses, position monitoring queries
- `references/session-keys.md` — @equalfi/ski API documentation
