---
name: equalfi-amm
description: EqualFi protocol operations via session keys. Use when interacting with EqualFi Position Agents, executing AMM operations, managing session keys with @equalfi/ski, or querying position state on Base/ETH/Arbitrum Sepolia testnets.
---

# EqualFi Protocol Operations

This skill provides the addresses, ABIs, and procedures for interacting with the EqualFi protocol via session keys.

## First-Time Setup

Before executing any operations, ask the user:

> "Do you want to install @equalfi/ski (EqualFi Session Key Installer)? This is required to interact with the protocol via session keys."

If yes, run:

```bash
pnpm dlx @equalfi/ski
```

This will:
- Prompt for Position NFT ID
- Prompt for Entity ID (default: 7)
- Generate a session key
- Store it encrypted at `~/.openclaw/keys/equalfi/position-<id>.json`
- Print the session key address

After installation, use the helper scripts in `scripts/` for operations.

## ⚠️ Required: NFT Approval & TBA Gas Funding

Before session key operations will work:

1. **Fund the TBA with gas**: The TBA needs native ETH to pay for transaction gas. Send ETH directly to the TBA address.

2. **Approve the TBA on the Position NFT**: The user **must approve the TBA on the Position NFT**.

Before executing any session key operation, ask the user:

> "Has the TBA been funded with gas? Has the Position NFT approved the TBA? Both are required for session key operations. If not:
> 1. Send ETH to the TBA address for gas
> 2. Call `setApprovalForAll(TBA_ADDRESS, true)` or `approve(TBA_ADDRESS, TOKEN_ID)` on the Position NFT contract (`0x560beed75ba42f99602f8786abc4700c8b4cb1c5`)."

**Why:** `createAuction` and other operations check NFT ownership. The TBA is `msg.sender`, so the Position NFT must approve the TBA to pass this check.

**Note:** Approval only satisfies the NFT ownership check — session-key policy still gates what can be executed.

## Helper Scripts

All scripts output JSON. Use `--help` for usage.

### test-session.js
Verify session key is installed and working:
```bash
node scripts/test-session.js --token-id 1 --rpc https://sepolia.base.org
```

### get-tba.js
Get TBA address for a position:
```bash
node scripts/get-tba.js --token-id 1 --rpc https://sepolia.base.org
```

### query-position.js
Query position state and pool memberships:
```bash
node scripts/query-position.js --token-id 1 --pool-id 1 --rpc https://sepolia.base.org
```

### create-auction.js
Create AMM auction via session key:
```bash
node scripts/create-auction.js \
  --token-id 1 \
  --pool-a 1 --pool-b 2 \
  --reserve-a 1000000000000000000 \
  --reserve-b 1000000000000000000 \
  --duration-seconds 3600 \
  --fee-bps 30 \
  --fee-asset 0 \
  --rpc https://sepolia.base.org \
  --chain-id 84532
```

### roll-yield.js
Roll yield from pool to position:
```bash
node scripts/roll-yield.js \
  --token-id 1 \
  --pool-id 1 \
  --rpc https://sepolia.base.org \
  --chain-id 84532
```

### cancel-auction.js
Cancel an AMM auction:
```bash
node scripts/cancel-auction.js \
  --token-id 1 \
  --auction-id 1 \
  --rpc https://sepolia.base.org \
  --chain-id 84532
```

### finalize-auction.js
Finalize an AMM auction:
```bash
node scripts/finalize-auction.js \
  --token-id 1 \
  --auction-id 1 \
  --rpc https://sepolia.base.org \
  --chain-id 84532
```

### add-liquidity.js
Add liquidity to an AMM auction:
```bash
# Specify both amounts
node scripts/add-liquidity.js \
  --token-id 1 \
  --auction-id 1 \
  --amount-a 1000000000000000000 \
  --amount-b 2000000000000000000 \
  --rpc https://sepolia.base.org \
  --chain-id 84532

# Or let it calculate amountB from the auction's ratio
node scripts/add-liquidity.js \
  --token-id 1 \
  --auction-id 1 \
  --amount-a 1000000000000000000 \
  --rpc https://sepolia.base.org \
  --chain-id 84532
```
**Note**: This locks funds from the Position's existing balance in the Diamond pools, not from the TBA's token balance. The Position must have sufficient unlocked deposits in both poolIdA and poolIdB. The script will automatically calculate `amountB` from the auction's current reserve ratio if not provided.

### join-community-auction.js
Join a community auction:
```bash
node scripts/join-community-auction.js \
  --token-id 1 \
  --auction-id 1 \
  --amount-a 1000000000000000000 \
  --amount-b 1000000000000000000 \
  --rpc https://sepolia.base.org \
  --chain-id 84532
```

### finalize-community-auction.js
Finalize a community auction:
```bash
node scripts/finalize-community-auction.js \
  --token-id 1 \
  --auction-id 1 \
  --rpc https://sepolia.base.org \
  --chain-id 84532
```

## Networks

| Network | Chain ID | RPC |
|---------|----------|-----|
| Base Sepolia | 84532 | `https://sepolia.base.org` |
| ETH Sepolia | 11155111 | `https://ethereum-sepolia.publicnode.com` |
| Arbitrum Sepolia | 421614 | `https://sepolia-rollup.arbitrum.io/rpc` |

All contracts deployed to identical addresses across networks.

## Deployed Addresses

### Core

| Contract | Address |
|----------|---------|
| Diamond | `0x027c9ba58be0af69c990da55630d9042d067652b` |
| Position NFT | `0x560beed75ba42f99602f8786abc4700c8b4cb1c5` |
| Faucet | `0x1261959bc4a9094b360523b53f7c56af373881ee` |

### Modules

| Module | Address |
|--------|---------|
| Session Key Module | `0x43ac98fa18ca88ae37596eb667c70317bfa1bade` |
| AMM Skill Module | `0x4579328ED17bF3Ba0c4e79ddbAD2Ff54E49Fdcd6` |

### Derivative Tokens

| Token | Address |
|-------|---------|
| Option Token | `0x41846a120acA3A794E606f937f6245a92257CdF0` |
| Futures Token | `0xdE559E6DB58A64e70DCD6DD27D408e37756943A5` |

### Pool Underlyings

| Pool | Address |
|------|---------|
| Pool 1 | `0x6a2a2edd60050617b9508e6d11901e25627e05fd` |
| Pool 2 | `0xd066def718cfdf12a316ba108a4bed93052e504c` |
| Pool 3 | `0x70e40142899ab58fda999886d616c64b7a78719a` |
| Pool 4 | `0x3d461b43473d89fe4e544cd5aca3148c268eb298` |
| Pool 5 | `0x30f89ed1ce6a8d4ea6cdd47f5e657d52496baa82` |
| Pool 6 | `0x0000000000000000000000000000000000000000` (ETH) |

### Registries

| Registry | Address |
|----------|---------|
| Identity | `0x8004A818BFB912233c491871b3d84c89A494BD9e` |
| Reputation | `0x8004B663056A597Dffe9eCcC1965A193B7388713` |
| Validation | `0x8004Cb1BF31DAf7788923b405b754f57acEB4272` |

## Session Key Management

See `references/session-keys.md` for full @equalfi/ski documentation.

### Active Session Key

| Field | Value |
|-------|-------|
| Label | `position-1` |
| Address | `0x2aDA49FD896c61ec27D9135e51C3f423f8623D4A` |
| Entity ID | `7` |

### CLI Commands

```bash
# List keys
ski list

# Show metadata
ski show --label position-1 --json

# Test validation
ski test --label position-1 --rpc <rpc-url> --tba <tba-address> --module 0x43ac98fa18ca88ae37596eb667c70317bfa1bade
```

### Runtime API

```javascript
const { loadSessionWallet, executeWithRuntimeValidation } = require('@equalfi/ski');

const wallet = await loadSessionWallet('position-1');

await executeWithRuntimeValidation({
  rpcUrl: 'https://sepolia.base.org',
  tbaAddress: '<tba-address>',
  moduleAddress: '0x43ac98fa18ca88ae37596eb667c70317bfa1bade',
  entityId: 7,
  data: encodedCalldata,
  value: 0n,
  sessionWallet: wallet,
  chainId: 84532
});
```

## AMM Skill Operations

All operations target the Diamond contract (`0x027c9ba58be0af69c990da55630d9042d067652b`), not the AMM Skill Module.

**IMPORTANT**: There are two types of auctions with separate ID spaces:
- **Solo/AMM Auctions**: Created with `createAuction()`, use `finalizeAuction()`, `cancelAuction()`, `addLiquidity()`
- **Community Auctions**: Created with `createCommunityAuction()`, use `finalizeCommunityAuction()`, `joinCommunityAuction()`

They have separate ID counters, so auction ID 6 could exist as both a Solo auction AND a Community auction. Always use the correct function for the auction type.

### Selector Reference

| Function | Selector | Target |
|----------|----------|--------|
| `createAuction` | `0xed5b5ef5` | Diamond |
| `cancelAuction` | `0x96b5a755` | Diamond |
| `finalizeAuction` | `0xe8083863` | Diamond |
| `addLiquidity` | `0x422f1043` | Diamond |
| `joinCommunityAuction` | `0x4b43f282` | Diamond |
| `finalizeCommunityAuction` | `0xbc3b2542` | Diamond |
| `rollYieldToPosition` | `0xc88d8213` | Diamond |

### Session Key Policy Example

```json
{
  "validAfter": "now",
  "validUntil": "+1h",
  "valueLimit": "0 USDC",
  "budget": "0 USDC",
  "permissions": [
    {
      "target": "0x027c9ba58be0af69c990da55630d9042d067652b",
      "selectors": [
        "0xed5b5ef5",
        "0x96b5a755",
        "0xe8083863",
        "0x422f1043",
        "0x4b43f282",
        "0xbc3b2542",
        "0xc88d8213"
      ]
    }
  ]
}
```

### createAuction

```javascript
const params = {
  positionId: tokenId,      // Must match TBA's bound NFT
  poolIdA: 1,
  poolIdB: 2,
  reserveA: amountA,
  reserveB: amountB,
  startTime: timestamp,
  endTime: timestamp,
  feeBps: 30,
  feeAsset: 0
};
```

### cancelAuction

```javascript
await cancelAuction(auctionId);
// Requires: policy.allowCancel == true
```

### finalizeAuction

```javascript
await finalizeAuction(auctionId);
// Requires: policy.allowFinalize == true
// Finalizes a SOLO/AMM auction after duration expires
// NOTE: This is for AMM auctions created with createAuction()
// For community auctions, use finalizeCommunityAuction() instead
```

### addLiquidity

```javascript
await addLiquidity(auctionId, amountA, amountB);
// Requires: policy.allowAddLiquidity == true
// Adds liquidity to an existing AMM auction
// NOTE: Locks funds from the Position's balance in the Diamond (poolIdA and poolIdB)
// The Position must have sufficient unlocked balance in both pools
// Does NOT transfer tokens from the TBA - uses Position's existing pool deposits
// IMPORTANT: amountA and amountB must maintain the auction's current reserve ratio
// Query getAuction(auctionId) to get reserveA and reserveB, then calculate:
//   amountB = (amountA * reserveB) / reserveA
```

### joinCommunityAuction

```javascript
await joinCommunityAuction(auctionId, amountA, amountB);
// Requires: policy.allowCommunityJoin == true
// Join a community auction with liquidity
```

### finalizeCommunityAuction

```javascript
await finalizeCommunityAuction(auctionId);
// Requires: policy.allowFinalize == true
// Finalizes a COMMUNITY auction after duration expires
// NOTE: This is for community auctions created with createCommunityAuction()
// For solo/AMM auctions, use finalizeAuction() instead
```

### rollYieldToPosition

```javascript
await rollYieldToPosition(tokenId, poolId);
// Rolls accrued yield from pool to position principal
```

## Position Monitoring

See `references/protocol-reference.md` for complete ABIs and query examples.

### Key Queries

```javascript
// Position state
diamond.getPositionState(tokenId, poolId)

// Pool memberships
diamond.getPositionPoolMemberships(tokenId)

// Session key policy
sessionKeyModule.getSessionKeyPolicy(tbaAddress, 7, sessionKeyAddress)

// Auction state
diamond.getAuction(auctionId)

// TBA address for position
diamond.computeTBAAddress(tokenId)
```

## Reference Files

- `references/protocol-reference.md` — Full ABIs, all addresses, position monitoring queries
- `references/session-keys.md` — @equalfi/ski API documentation
