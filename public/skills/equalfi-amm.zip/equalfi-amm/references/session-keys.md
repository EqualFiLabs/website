# Session Key Operations (@equalfi/ski)

## Overview

@equalfi/ski manages session keys for EqualFi Position Agents. Keys are stored encrypted on disk with passwords in the OS keychain.

## Installation

```bash
pnpm dlx @equalfi/ski
```

## CLI Reference

```bash
ski init                        # Create new session key
ski list                        # List stored keys
ski show --label <label>        # Show key metadata
ski test --label <label> \      # Test runtime validation
  --rpc <url> \
  --tba <address> \
  --module <address>
```

### Flags

| Flag | Description |
|------|-------------|
| `--label` | Session key label (e.g., `position-1`) |
| `--entity` | Entity ID (default: 7) |
| `--json` | JSON output |
| `--rpc` | RPC URL for test |
| `--tba` | TBA address for test |
| `--module` | SessionKeyValidationModule address |
| `--data` | Calldata hex for test (default: nonce()) |

## Runtime API

### loadSessionWallet(label)

```javascript
const wallet = await loadSessionWallet('position-1');
// Returns: ethers.Wallet
```

### executeWithRuntimeValidation(options)

```javascript
const result = await executeWithRuntimeValidation({
  rpcUrl: string,          // RPC endpoint
  tbaAddress: string,      // Position's TBA address
  moduleAddress: string,   // SessionKeyValidationModule
  entityId: number,        // Entity ID (default: 7)
  data: string,            // ABI-encoded calldata
  value: bigint,           // ETH value (usually 0n)
  sessionWallet: Wallet,   // From loadSessionWallet
  chainId: number          // Chain ID
});
```

### buildRuntimeAuthorization(options)

Builds ERC-6900 authorization payload without sending.

```javascript
const { authorization, replayProtection, signature } = await buildRuntimeAuthorization({
  moduleAddress: string,
  account: string,         // TBA address
  entityId: number,
  sender: string,          // Session key address
  value: bigint,
  data: string,
  sessionWallet: Wallet,
  chainId: number
});
```

### callWithRuntimeValidation(options)

Static call version — returns result without sending transaction.

```javascript
const result = await callWithRuntimeValidation({ ...same options });
```

## Storage

| Item | Path |
|------|------|
| Keystore | `~/.openclaw/keys/equalfi/<label>.json` |
| Metadata | `~/.openclaw/keys/equalfi/<label>.meta.json` |
| Password | OS keychain (service: `equalfi-ski`) |

## Metadata Schema

```json
{
  "address": "0x...",
  "chainId": null,
  "skillId": "equalfi",
  "agentLabel": "position-1",
  "entityId": 7,
  "createdAt": "2026-02-20T10:18:39.837Z",
  "keychainService": "equalfi-ski",
  "keychainAccount": "session-key:equalfi:position-1"
}
```

## Session Key Policy

```solidity
struct SessionKeyPolicy {
  bool active;
  uint48 validAfter;        // Unix timestamp
  uint48 validUntil;        // Unix timestamp
  uint256 maxValuePerCall;
  uint256 cumulativeValueLimit;
}
```

Query via:

```javascript
const { policy, nonce, cumulativeValueUsed } = await sessionKeyValidationModule.getSessionKeyPolicy(
  tbaAddress,    // account
  7,             // entityId
  sessionKeyAddress
);
```

## Authorization Format

ERC-6900 runtime authorization structure:

```
authorization = encode(bytes24 moduleEntity, bytes moduleAuth)

moduleEntity = moduleAddress (20 bytes) + entityId (4 bytes padded)

moduleAuth = encode(address sessionKey, bytes32 replay, bytes signature)
```

The signature signs:

```solidity
keccak256(abi.encode(
  keccak256("AGENT_WALLET_SESSION_RUNTIME_V1"),  // tag
  chainId,
  moduleAddress,
  account,
  entityId,
  sender,
  value,
  keccak256(data),
  replay
))
```

## Error Handling

| Error | Cause |
|-------|-------|
| `Missing keychain entry` | Password not found in OS keychain |
| `Key already exists` | Label already used (use `allowOverwrite`) |
| `Runtime validation failed` | Session key not authorized or policy violated |

## Example: Execute AMM Operation

```javascript
const { loadSessionWallet, executeWithRuntimeValidation } = require('@equalfi/ski');
const { AbiCoder, keccak256, toUtf8Bytes } = require('ethers');

const wallet = await loadSessionWallet('position-1');
const coder = AbiCoder.defaultAbiCoder();

// Encode parameters
const params = [tokenId, poolIdA, poolIdB, reserveA, reserveB, startTime, endTime, feeBps, feeAsset];
const data = coder.encode(['(uint256,uint256,uint256,uint256,uint256,uint64,uint64,uint16,uint8)'], [params]);

// Get function selector
const selector = keccak256(toUtf8Bytes('createAuction((uint256,uint256,uint256,uint256,uint256,uint64,uint64,uint16,uint8))')).slice(0, 10);
const calldata = selector + data.slice(2);

// Execute
await executeWithRuntimeValidation({
  rpcUrl: 'https://sepolia.base.org',
  tbaAddress: tba,
  moduleAddress: '0x43ac98fa18ca88ae37596eb667c70317bfa1bade',
  entityId: 7,
  data: calldata,
  value: 0n,
  sessionWallet: wallet,
  chainId: 84532
});
```
