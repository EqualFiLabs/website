# EqualFi Demo Reference

**Updated:** 2026-02-21 12:00 MST
**Purpose:** OpenClaw skill for judges to run EqualFi demo operations via session keys

---

## Overview

The demo showcases an AI agent (Eve) controlling a Position NFT via:
- **ERC-6551 TBA** (Token Bound Account) — the agent's wallet
- **ERC-6900 Session Key Module** — bounded, revocable permissions
- **PositionAgentAmmSkillModule** — execution module for AMM operations

---

## Components

### 1. PositionAgentAmmSkillModule.sol

**Location:** `Projects/EqualFi/src/agent-wallet/erc6900/PositionAgentAmmSkillModule.sol`

**Module ID:** `equallend.amm-auction-skill.1.0.0`

**Key Functions (Agent-callable):**

| Function | Purpose |
|----------|---------|
| `createAuction(CreateAuctionParams)` | Create AMM auction bound to Position NFT |
| `cancelAuction(auctionId)` | Cancel an auction (if policy allows) |
| `rollYieldToPosition(tokenId, pid)` | Roll yield from pool back to position |

**Policy Layer:**

```solidity
struct AuctionPolicy {
    bool enabled;
    bool allowCancel;
    bool enforcePoolAllowlist;
    uint64 minDuration;
    uint64 maxDuration;
    uint16 minFeeBps;
    uint16 maxFeeBps;
    uint256 minReserveA;
    uint256 maxReserveA;
    uint256 minReserveB;
    uint256 maxReserveB;
}

struct RollPolicy {
    bool enabled;
    bool enforcePoolAllowlist;
}
```

**Security:**
- `_boundTokenId()` — pulls TBA's underlying NFT tokenId via ERC-6551
- All operations must match that tokenId (no cross-position attacks)
- Owner-only config functions

---

### 2. @equalfi/ski — Session Key Installer

**Location:** `Projects/equalfi-ski/`

**Install:**
```bash
pnpm dlx @equalfi/ski
```

**CLI Commands:**
```bash
ski init                        # Create new session key (interactive)
ski list                        # List stored keys
ski show --label <label>        # Show key metadata
ski test --label <label> \      # Test runtime validation
  --rpc <url> \
  --tba <address> \
  --module <address>
```

**Runtime API (for agents):**
```javascript
const {
  loadSessionWallet,
  buildRuntimeAuthorization,
  executeWithRuntimeValidation
} = require('@equalfi/ski');

// Load the session wallet
const wallet = await loadSessionWallet('position-1');

// Execute through TBA with session key auth
await executeWithRuntimeValidation({
  rpcUrl: 'https://sepolia.base.org',
  tbaAddress: '0x...',
  moduleAddress: '0x...',
  entityId: 7,
  data: encodedCalldata,
  value: 0n,
  sessionWallet: wallet,
  chainId: 84532
});
```

**Key Locations:**
- Keystore: `~/.openclaw/keys/equalfi/<label>.json`
- Metadata: `~/.openclaw/keys/equalfi/<label>.meta.json`
- Password: OS keychain (`equalfi-ski` service)

---

### 3. Active Session Key

| Field | Value |
|-------|-------|
| **Label** | `position-1` |
| **Session Key Address** | `0x2aDA49FD896c61ec27D9135e51C3f423f8623D4A` |
| **Entity ID** | `7` |
| **Created** | 2026-02-20 10:18:39 UTC |
| **Keystore** | `~/.openclaw/keys/equalfi/position-1.json` |

---

## Deployed Networks

Protocol live on:
- **Base Sepolia** (chainId: 84532) — RPC: `https://sepolia.base.org`
- **ETH Sepolia** (chainId: 11155111) — RPC: `https://ethereum-sepolia.publicnode.com`
- **Arbitrum Sepolia** (chainId: 421614) — RPC: `https://sepolia-rollup.arbitrum.io/rpc`

All contracts deployed to the same addresses across all three testnets (deterministic deployment).

---

### Core Contracts

| Contract | Address |
|----------|---------|
| Diamond | `0x027c9ba58be0af69c990da55630d9042d067652b` |
| Position NFT | `0x560beed75ba42f99602f8786abc4700c8b4cb1c5` |
| Faucet | `0x1261959bc4a9094b360523b53f7c56af373881ee` |

### Derivative Tokens

| Token | Address |
|-------|---------|
| Option Token | `0x41846a120acA3A794E606f937f6245a92257CdF0` |
| Futures Token | `0xdE559E6DB58A64e70DCD6DD27D408e37756943A5` |

### Pool Underlying Tokens

| Pool | Underlying Address |
|------|-------------------|
| Pool 1 | `0x6a2a2edd60050617b9508e6d11901e25627e05fd` |
| Pool 2 | `0xd066def718cfdf12a316ba108a4bed93052e504c` |
| Pool 3 | `0x70e40142899ab58fda999886d616c64b7a78719a` |
| Pool 4 | `0x3d461b43473d89fe4e544cd5aca3148c268eb298` |
| Pool 5 | `0x30f89ed1ce6a8d4ea6cdd47f5e657d52496baa82` |
| Pool 6 | `0x0000000000000000000000000000000000000000` (ETH) |

### Modules

| Module | Address |
|--------|---------|
| Session Key Module | `0x43ac98fa18ca88ae37596eb667c70317bfa1bade` |
| AMM Skill Module | `0x402DfcF43f1e9a7101717A97322bfA621c6a7a47` |

### Registries

| Registry | Address |
|----------|---------|
| Identity Registry | `0x8004A818BFB912233c491871b3d84c89A494BD9e` |
| Reputation Registry | `0x8004B663056A597Dffe9eCcC1965A193B7388713` |
| Validation Registry | `0x8004Cb1BF31DAf7788923b405b754f57acEB4272` |

---

## ABIs (Agent-Relevant)

### ERC-6551 TBA Interface (IERC6551Account)

Used to get the underlying NFT info from the TBA.

```javascript
const erc6551AccountAbi = [
  // Returns (chainId, tokenContract, tokenId)
  {
    name: 'token',
    type: 'function',
    stateMutability: 'view',
    inputs: [],
    outputs: [
      { name: 'chainId', type: 'uint256' },
      { name: 'tokenContract', type: 'address' },
      { name: 'tokenId', type: 'uint256' }
    ]
  },
  {
    name: 'owner',
    type: 'function',
    stateMutability: 'view',
    inputs: [],
    outputs: [{ name: '', type: 'address' }]
  }
];
```

### ERC-6900 Account Interface (executeWithRuntimeValidation)

The key function for agents to execute through the TBA.

```javascript
const erc6900ExecuteAbi = [
  {
    name: 'executeWithRuntimeValidation',
    type: 'function',
    stateMutability: 'payable',
    inputs: [
      { name: 'data', type: 'bytes' },
      { name: 'authorization', type: 'bytes' }
    ],
    outputs: [{ name: '', type: 'bytes' }]
  }
];
```

### PositionAgentAmmSkillModule

Agent-executable functions for AMM operations.

```javascript
const positionAgentAmmSkillModuleAbi = [
  {
    name: 'createAuction',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [
      {
        name: 'params',
        type: 'tuple',
        components: [
          { name: 'positionId', type: 'uint256' },
          { name: 'poolIdA', type: 'uint256' },
          { name: 'poolIdB', type: 'uint256' },
          { name: 'reserveA', type: 'uint256' },
          { name: 'reserveB', type: 'uint256' },
          { name: 'startTime', type: 'uint64' },
          { name: 'endTime', type: 'uint64' },
          { name: 'feeBps', type: 'uint16' },
          { name: 'feeAsset', type: 'uint8' }
        ]
      }
    ],
    outputs: [{ name: 'auctionId', type: 'uint256' }]
  },
  {
    name: 'cancelAuction',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [{ name: 'auctionId', type: 'uint256' }],
    outputs: []
  },
  {
    name: 'rollYieldToPosition',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [
      { name: 'tokenId', type: 'uint256' },
      { name: 'pid', type: 'uint256' }
    ],
    outputs: []
  },
  // View functions
  {
    name: 'getAuctionPolicy',
    type: 'function',
    stateMutability: 'view',
    inputs: [],
    outputs: [
      {
        name: 'policy',
        type: 'tuple',
        components: [
          { name: 'enabled', type: 'bool' },
          { name: 'allowCancel', type: 'bool' },
          { name: 'enforcePoolAllowlist', type: 'bool' },
          { name: 'minDuration', type: 'uint64' },
          { name: 'maxDuration', type: 'uint64' },
          { name: 'minFeeBps', type: 'uint16' },
          { name: 'maxFeeBps', type: 'uint16' },
          { name: 'minReserveA', type: 'uint256' },
          { name: 'maxReserveA', type: 'uint256' },
          { name: 'minReserveB', type: 'uint256' },
          { name: 'maxReserveB', type: 'uint256' }
        ]
      }
    ]
  },
  {
    name: 'getRollPolicy',
    type: 'function',
    stateMutability: 'view',
    inputs: [],
    outputs: [
      {
        name: 'policy',
        type: 'tuple',
        components: [
          { name: 'enabled', type: 'bool' },
          { name: 'enforcePoolAllowlist', type: 'bool' }
        ]
      }
    ]
  },
  {
    name: 'isPoolAllowed',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'poolId', type: 'uint256' }],
    outputs: [{ name: '', type: 'bool' }]
  },
  {
    name: 'getDiamond',
    type: 'function',
    stateMutability: 'view',
    inputs: [],
    outputs: [{ name: '', type: 'address' }]
  },
  {
    name: 'moduleId',
    type: 'function',
    stateMutability: 'pure',
    inputs: [],
    outputs: [{ name: '', type: 'string' }]
  }
];
```

### SessionKeyValidationModule

For viewing session key policies.

```javascript
const sessionKeyValidationModuleAbi = [
  {
    name: 'getSessionKeyPolicy',
    type: 'function',
    stateMutability: 'view',
    inputs: [
      { name: 'account', type: 'address' },
      { name: 'entityId', type: 'uint32' },
      { name: 'sessionKey', type: 'address' }
    ],
    outputs: [
      {
        name: 'policy',
        type: 'tuple',
        components: [
          { name: 'active', type: 'bool' },
          { name: 'validAfter', type: 'uint48' },
          { name: 'validUntil', type: 'uint48' },
          { name: 'maxValuePerCall', type: 'uint256' },
          { name: 'cumulativeValueLimit', type: 'uint256' }
        ]
      },
      { name: 'nonce', type: 'uint64' },
      { name: 'targetCount', type: 'uint256' },
      { name: 'selectorCount', type: 'uint256' },
      { name: 'targetSelectorRuleCount', type: 'uint256' },
      { name: 'cumulativeValueUsed', type: 'uint256' }
    ]
  }
];
```

### AmmAuctionFacet (via Diamond)

For reading auction state after creation.

```javascript
const ammAuctionFacetAbi = [
  {
    name: 'getAuction',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'auctionId', type: 'uint256' }],
    outputs: [
      {
        name: '',
        type: 'tuple',
        components: [
          { name: 'makerPositionKey', type: 'bytes32' },
          { name: 'makerPositionId', type: 'uint256' },
          { name: 'poolIdA', type: 'uint256' },
          { name: 'poolIdB', type: 'uint256' },
          { name: 'tokenA', type: 'address' },
          { name: 'tokenB', type: 'address' },
          { name: 'reserveA', type: 'uint256' },
          { name: 'reserveB', type: 'uint256' },
          { name: 'initialReserveA', type: 'uint256' },
          { name: 'initialReserveB', type: 'uint256' },
          { name: 'invariant', type: 'uint256' },
          { name: 'startTime', type: 'uint64' },
          { name: 'endTime', type: 'uint64' },
          { name: 'feeBps', type: 'uint16' },
          { name: 'feeAsset', type: 'uint8' },
          { name: 'makerFeeAAccrued', type: 'uint256' },
          { name: 'makerFeeBAccrued', type: 'uint256' },
          { name: 'treasuryFeeAAccrued', type: 'uint256' },
          { name: 'treasuryFeeBAccrued', type: 'uint256' },
          { name: 'active', type: 'bool' },
          { name: 'finalized', type: 'bool' }
        ]
      }
    ]
  },
  {
    name: 'previewSwap',
    type: 'function',
    stateMutability: 'view',
    inputs: [
      { name: 'auctionId', type: 'uint256' },
      { name: 'tokenIn', type: 'address' },
      { name: 'amountIn', type: 'uint256' }
    ],
    outputs: [
      { name: 'amountOut', type: 'uint256' },
      { name: 'feeAmount', type: 'uint256' }
    ]
  }
];
```

### PositionAgentTBAFacet (via Diamond)

For computing TBA address.

```javascript
const positionAgentTBAFacetAbi = [
  {
    name: 'computeTBAAddress',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'positionTokenId', type: 'uint256' }],
    outputs: [{ name: '', type: 'address' }]
  }
];
```

### Position NFT

For querying position ownership.

```javascript
const positionNFTAbi = [
  {
    name: 'ownerOf',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'tokenId', type: 'uint256' }],
    outputs: [{ name: '', type: 'address' }]
  },
  {
    name: 'getPositionKey',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'tokenId', type: 'uint256' }],
    outputs: [{ name: '', type: 'bytes32' }]
  }
];
```

---

## Position Monitoring Reference

These queries let the agent answer questions about the user's position state.

### 1. Get Position Token ID

If you know the owner's address:

```javascript
// Via Position NFT
const tokenId = await positionNFT.tokenOfOwnerByIndex(ownerAddress, 0);
```

### 2. Get TBA Address for a Position

```javascript
// Via Diamond's TBA facet
const tbaAddress = await diamond.computeTBAAddress(tokenId);
```

### 3. Get Underlying NFT Info from TBA

```javascript
// Via ERC-6551 TBA
const [chainId, tokenContract, tokenId] = await tba.token();
```

### 4. Query Position State (per pool)

```javascript
// Via Diamond's position view facet
const state = await diamond.getPositionState(tokenId, poolId);
// Returns: principal, accruedYield, totalDebt, solvencyRatio, isDelinquent, rollingLoan, fixedLoanIds, etc.
```

### 5. Query Position Encumbrance

```javascript
const encumbrance = await diamond.getPositionEncumbrance(tokenId, poolId);
// Returns: directLocked, directLent, directOfferEscrow, indexEncumbered, totalEncumbered
```

### 6. List All Pool Memberships for a Position

```javascript
const memberships = await diamond.getPositionPoolMemberships(tokenId);
// Returns array of: poolId, underlying, isMember, hasBalance, hasActiveLoans
```

### 7. Get Pool Configuration

```javascript
const poolInfo = await diamond.getPoolConfigSummary(poolId);
// Returns: isCapped, depositCap, underlying, depositorLTVBps, rollingApyBps
```

### 8. Get Session Key Policy Status

```javascript
const { policy, nonce, cumulativeValueUsed } = await sessionKeyValidationModule.getSessionKeyPolicy(
  tbaAddress,      // account
  entityId,        // 7
  sessionKeyAddress
);
// Returns: active, validAfter, validUntil, maxValuePerCall, cumulativeValueLimit
```

### 9. Get AMM Skill Policy

```javascript
const auctionPolicy = await ammSkillModule.getAuctionPolicy();
const rollPolicy = await ammSkillModule.getRollPolicy();
const poolAllowed = await ammSkillModule.isPoolAllowed(poolId);
```

### 10. Query Auction State

```javascript
const auction = await diamond.getAuction(auctionId);
// Returns: makerPositionId, poolIdA/B, tokenA/B, reserves, startTime, endTime, feeBps, active, finalized

const [amountOut, feeAmount] = await diamond.previewSwap(auctionId, tokenIn, amountIn);
```

---

## Example Queries

**"What's my position worth?"**
```javascript
const state = await diamond.getPositionState(tokenId, poolId);
const totalValue = state.principal + state.accruedYield;
```

**"Am I solvent?"**
```javascript
const state = await diamond.getPositionState(tokenId, poolId);
// solvencyRatio > 10000 = solvent (100% = 10000 basis points)
const isSolvent = state.solvencyRatio >= 10000;
```

**"Do I have any active loans?"**
```javascript
const memberships = await diamond.getPositionPoolMemberships(tokenId);
const poolsWithLoans = memberships.filter(m => m.hasActiveLoans);
```

**"What pools am I in?"**
```javascript
const memberships = await diamond.getPositionPoolMemberships(tokenId);
const activePools = memberships.filter(m => m.isMember);
```

**"Is my session key still valid?"**
```javascript
const { policy } = await sessionKeyValidationModule.getSessionKeyPolicy(tba, 7, sessionKey);
const now = Math.floor(Date.now() / 1000);
const isValid = policy.active && now >= policy.validAfter && now <= policy.validUntil;
```

---

## Demo Flow (Planned)

1. **Setup:** Judge points agent at the EqualFi skill
2. **Agent reads:** Skill provides all addresses, ABIs, pool IDs
3. **Agent executes:**
   - Load session wallet via `@equalfi/ski`
   - Build calldata for `createAuction()` or `rollYieldToPosition()`
   - Call `executeWithRuntimeValidation()` through TBA
4. **Narration:** Agent explains what it's doing in real-time

---

## Files to Reference

| File | Purpose |
|------|---------|
| `Projects/EqualFi/src/agent-wallet/erc6900/PositionAgentAmmSkillModule.sol` | AMM skill module source |
| `Projects/equalfi-ski/lib/session.js` | Session key runtime library |
| `Projects/equalfi-ski/bin/cli.js` | CLI tool source |
| `Projects/website/src/lib/abis/positionAgentAmmSkillModule.js` | ABI export |

---

## Next Steps

- [x] Collect deployed addresses for all 3 testnets
- [x] Extract ABIs for TBA interface + AmmSkillModule
- [ ] Build OpenClaw skill scaffold (SKILL.md + helpers)
- [ ] Create calldata encoding helpers for demo operations
- [ ] Test end-to-end flow on one testnet

---

## Notes

- Default entity ID is `7`
- Session keys are stored encrypted; password in OS keychain
- `ski test` defaults to calling `nonce()` selector (`0xaffed0e0`)
- Policy configuration is owner-only (not agent-callable)
