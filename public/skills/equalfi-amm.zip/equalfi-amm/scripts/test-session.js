#!/usr/bin/env node
/**
 * Test session key validation
 * 
 * Usage:
 *   node test-session.js --token-id <id> --rpc <url> [--label position-1]
 * 
 * Calls nonce() through the TBA via session key to verify setup.
 */

const { JsonRpcProvider, Contract } = require('ethers');
const path = require('path');
const os = require('os');

const DIAMOND = '0x027c9ba58be0af69c990da55630d9042d067652b';
const SESSION_KEY_MODULE = '0x43ac98fa18ca88ae37596eb667c70317bfa1bade';

const tbaFacetAbi = [
  {
    name: 'computeTBAAddress',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'positionTokenId', type: 'uint256' }],
    outputs: [{ name: '', type: 'address' }]
  }
];

const sessionKeyModuleAbi = [
  {
    name: 'getSessionKeyPolicy',
    type: 'function',
    stateMutability: 'view',
    inputs: [
      { name: 'account', type: 'address' },
      { name: 'entityId', type: 'uint32' },
      { name: 'sessionKey', type: 'address' }
    ],
    outputs: [
      {
        name: 'policy',
        type: 'tuple',
        components: [
          { name: 'active', type: 'bool' },
          { name: 'validAfter', type: 'uint48' },
          { name: 'validUntil', type: 'uint48' },
          { name: 'maxValuePerCall', type: 'uint256' },
          { name: 'cumulativeValueLimit', type: 'uint256' }
        ]
      },
      { name: 'nonce', type: 'uint64' },
      { name: 'targetCount', type: 'uint256' },
      { name: 'selectorCount', type: 'uint256' },
      { name: 'targetSelectorRuleCount', type: 'uint256' },
      { name: 'cumulativeValueUsed', type: 'uint256' }
    ]
  }
];

function parseArgs() {
  const args = process.argv.slice(2);
  const flags = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) {
      const key = args[i].slice(2).replace(/-([a-z])/g, (_, c) => c.toUpperCase());
      flags[key] = args[++i];
    }
  }
  return flags;
}

async function main() {
  const { tokenId, rpc, label = 'position-1' } = parseArgs();

  if (!tokenId || !rpc) {
    console.error(JSON.stringify({ error: 'Missing --token-id or --rpc' }));
    process.exit(1);
  }

  const provider = new JsonRpcProvider(rpc);
  const diamond = new Contract(DIAMOND, tbaFacetAbi, provider);
  const sessionModule = new Contract(SESSION_KEY_MODULE, sessionKeyModuleAbi, provider);

  // Get TBA address
  const tbaAddress = await diamond.computeTBAAddress(tokenId);
  console.error(`TBA: ${tbaAddress}`);

  // Load session wallet
  const skiPath = path.join(os.homedir(), '.openclaw', 'workspace', 'Projects', 'equalfi-ski', 'lib', 'session.js');
  let ski;
  try {
    ski = require(skiPath);
  } catch (e) {
    console.error(JSON.stringify({
      error: 'Could not load @equalfi/ski',
      hint: 'Run: pnpm dlx @equalfi/ski'
    }));
    process.exit(1);
  }

  const { loadSessionWallet } = ski;
  const sessionWallet = await loadSessionWallet(label);
  console.error(`Session key: ${sessionWallet.address}`);

  // Query policy status
  let policyInfo;
  try {
    const [policy, nonce, targetCount, selectorCount] = await sessionModule.getSessionKeyPolicy(
      tbaAddress,
      7,
      sessionWallet.address
    );
    const now = Math.floor(Date.now() / 1000);
    const isValid = policy.active && 
                    now >= policy.validAfter && 
                    now <= policy.validUntil;

    policyInfo = {
      active: policy.active,
      validAfter: policy.validAfter.toString(),
      validUntil: policy.validUntil.toString(),
      maxValuePerCall: policy.maxValuePerCall.toString(),
      cumulativeValueLimit: policy.cumulativeValueLimit.toString(),
      nonce: nonce.toString(),
      targetCount: targetCount.toString(),
      selectorCount: selectorCount.toString(),
      isValid,
      currentTime: now
    };
  } catch (e) {
    policyInfo = { error: e.message, hint: 'Session key may not be installed on TBA' };
  }

  // Test runtime validation with nonce() call
  let testResult;
  try {
    const { callWithRuntimeValidation } = ski;
    const nonceSelector = '0xaffed0e0'; // nonce()
    
    const result = await callWithRuntimeValidation({
      rpcUrl: rpc,
      tbaAddress,
      moduleAddress: SESSION_KEY_MODULE,
      entityId: 7,
      data: nonceSelector,
      value: 0n,
      sessionWallet,
      chainId: (await provider.getNetwork()).chainId
    });

    testResult = {
      success: true,
      result
    };
  } catch (e) {
    testResult = {
      success: false,
      error: e.message
    };
  }

  console.log(JSON.stringify({
    tokenId,
    tbaAddress,
    sessionKeyAddress: sessionWallet.address,
    label,
    policy: policyInfo,
    testCall: testResult
  }, null, 2));
}

main().catch(e => {
  console.error(JSON.stringify({ error: e.message }));
  process.exit(1);
});
