#!/usr/bin/env node
/**
 * Compute TBA address for a Position NFT
 * 
 * Usage:
 *   node get-tba.js --token-id <id> --rpc <url>
 * 
 * Outputs JSON with TBA address
 */

const { JsonRpcProvider, Contract } = require('ethers');

const DIAMOND = '0x027c9ba58be0af69c990da55630d9042d067652b';

const tbaFacetAbi = [
  {
    name: 'computeTBAAddress',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'positionTokenId', type: 'uint256' }],
    outputs: [{ name: '', type: 'address' }]
  }
];

function parseArgs() {
  const args = process.argv.slice(2);
  const flags = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) {
      const key = args[i].slice(2).replace(/-([a-z])/g, (_, c) => c.toUpperCase());
      flags[key] = args[++i];
    }
  }
  return flags;
}

async function main() {
  const { tokenId, rpc } = parseArgs();

  if (!tokenId || !rpc) {
    console.error(JSON.stringify({ error: 'Missing --token-id or --rpc' }));
    process.exit(1);
  }

  const provider = new JsonRpcProvider(rpc);
  const diamond = new Contract(DIAMOND, tbaFacetAbi, provider);

  const tbaAddress = await diamond.computeTBAAddress(tokenId);

  console.log(JSON.stringify({
    tokenId,
    tbaAddress,
    diamond: DIAMOND
  }, null, 2));
}

main().catch(e => {
  console.error(JSON.stringify({ error: e.message }));
  process.exit(1);
});
