#!/usr/bin/env node
const { parseArgs } = require('node:util');
const { createPublicClient, http, encodeFunctionData } = require('viem');
const { loadSessionWallet, executeWithRuntimeValidation } = require('@equalfi/ski');

const SESSION_KEY_MODULE = '0x43ac98fa18ca88ae37596eb667c70317bfa1bade';
const DIAMOND = '0x027c9ba58be0af69c990da55630d9042d067652b';

const diamondAbi = [
  {
    name: 'addLiquidity',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [
      { name: 'auctionId', type: 'uint256' },
      { name: 'amountA', type: 'uint256' },
      { name: 'amountB', type: 'uint256' },
    ],
    outputs: [],
  },
];

const diamondAbi = [
  {
    name: 'getAuction',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'auctionId', type: 'uint256' }],
    outputs: [{
      name: '',
      type: 'tuple',
      components: [
        { name: 'makerPositionId', type: 'uint256' },
        { name: 'poolIdA', type: 'uint256' },
        { name: 'poolIdB', type: 'uint256' },
        { name: 'reserveA', type: 'uint256' },
        { name: 'reserveB', type: 'uint256' },
        { name: 'startTime', type: 'uint64' },
        { name: 'endTime', type: 'uint64' },
        { name: 'feeBps', type: 'uint16' },
        { name: 'feeAsset', type: 'uint8' },
        { name: 'active', type: 'bool' },
        { name: 'finalized', type: 'bool' },
      ],
    }],
  },
  {
    name: 'computeTBAAddress',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'tokenId', type: 'uint256' }],
    outputs: [{ name: '', type: 'address' }],
  },
];

async function main() {
  const { values } = parseArgs({
    options: {
      'token-id': { type: 'string' },
      'auction-id': { type: 'string' },
      'amount-a': { type: 'string' },
      'amount-b': { type: 'string' },
      'rpc': { type: 'string' },
      'chain-id': { type: 'string' },
      help: { type: 'boolean', short: 'h' },
    },
  });

  if (values.help) {
    console.log(`Usage: node add-liquidity.js --token-id <id> --auction-id <id> --amount-a <amount> [--amount-b <amount>] --rpc <url> --chain-id <id>

Add liquidity to an AMM auction via session key.

Options:
  --token-id <id>      Position NFT token ID
  --auction-id <id>    Auction ID
  --amount-a <amount>  Amount of token A (raw units)
  --amount-b <amount>  Amount of token B (raw units, optional - will calculate from ratio)
  --rpc <url>          RPC endpoint
  --chain-id <id>      Chain ID (84532, 11155111, 421614)
  -h, --help           Show this help

If --amount-b is not provided, it will be calculated from the auction's current reserve ratio.
`);
    process.exit(0);
  }

  const tokenId = values['token-id'];
  const auctionId = values['auction-id'];
  let amountA = values['amount-a'];
  let amountB = values['amount-b'];
  const rpcUrl = values.rpc;
  const chainId = parseInt(values['chain-id'] || '84532');

  if (!tokenId || !auctionId || !amountA || !rpcUrl) {
    console.error('Error: --token-id, --auction-id, --amount-a, and --rpc are required');
    process.exit(1);
  }

  const publicClient = createPublicClient({ transport: http(rpcUrl) });
  
  // Get auction to calculate ratio if amountB not provided
  const auction = await publicClient.readContract({
    address: DIAMOND,
    abi: diamondAbi,
    functionName: 'getAuction',
    args: [BigInt(auctionId)],
  });

  const reserveA = auction.reserveA;
  const reserveB = auction.reserveB;

  if (!amountB) {
    // Calculate amountB from ratio
    const amountABig = BigInt(amountA);
    const amountBBig = (amountABig * reserveB) / reserveA;
    amountB = amountBBig.toString();
    console.error(`Calculated amountB from ratio: ${amountB} (ratio ${reserveA}:${reserveB})`);
  }

  const wallet = await loadSessionWallet(`position-${tokenId}`);

  const tbaAddress = await publicClient.readContract({
    address: DIAMOND,
    abi: diamondAbi,
    functionName: 'computeTBAAddress',
    args: [BigInt(tokenId)],
  });

  const calldata = encodeFunctionData({
    abi: diamondAbi,
    functionName: 'addLiquidity',
    args: [BigInt(auctionId), BigInt(amountA), BigInt(amountB)],
  });

  const txHash = await executeWithRuntimeValidation({
    rpcUrl,
    tbaAddress,
    moduleAddress: SESSION_KEY_MODULE,
    entityId: 7,
    data: calldata,
    value: 0n,
    sessionWallet: wallet,
    chainId,
  });

  console.log(JSON.stringify({ success: true, txHash, auctionId, amountA, amountB, reserveA: reserveA.toString(), reserveB: reserveB.toString() }, null, 2));
}

main().catch((err) => {
  console.error(JSON.stringify({ success: false, error: err.message }, null, 2));
  process.exit(1);
});
