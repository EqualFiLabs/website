#!/usr/bin/env node
/**
 * Roll yield from pool to position via session key
 * 
 * Usage:
 *   node roll-yield.js \
 *     --token-id <id> \
 *     --pool-id <id> \
 *     --rpc <url> \
 *     --chain-id <id> \
 *     [--label position-1]
 * 
 * Requires @equalfi/ski to be installed and a session key configured.
 */

const { AbiCoder, keccak256, toUtf8Bytes, JsonRpcProvider, Contract } = require('ethers');
const path = require('path');
const os = require('os');

const DIAMOND = '0x027c9ba58be0af69c990da55630d9042d067652b';
const SESSION_KEY_MODULE = '0x43ac98fa18ca88ae37596eb667c70317bfa1bade';

const tbaFacetAbi = [
  {
    name: 'computeTBAAddress',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'positionTokenId', type: 'uint256' }],
    outputs: [{ name: '', type: 'address' }]
  }
];

function parseArgs() {
  const args = process.argv.slice(2);
  const flags = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) {
      const key = args[i].slice(2).replace(/-([a-z])/g, (_, c) => c.toUpperCase());
      flags[key] = args[++i];
    }
  }
  return flags;
}

async function main() {
  const {
    tokenId,
    poolId,
    rpc,
    chainId,
    label = 'position-1'
  } = parseArgs();

  if (!tokenId || !poolId || !rpc || !chainId) {
    console.error(JSON.stringify({
      error: 'Missing required args',
      required: ['token-id', 'pool-id', 'rpc', 'chain-id']
    }));
    process.exit(1);
  }

  // Load @equalfi/ski
  const skiPath = path.join(os.homedir(), '.openclaw', 'workspace', 'Projects', 'equalfi-ski', 'lib', 'session.js');
  let ski;
  try {
    ski = require(skiPath);
  } catch (e) {
    console.error(JSON.stringify({
      error: 'Could not load @equalfi/ski',
      hint: 'Run: pnpm dlx @equalfi/ski'
    }));
    process.exit(1);
  }

  const { loadSessionWallet, executeWithRuntimeValidation } = ski;

  const provider = new JsonRpcProvider(rpc);
  const diamond = new Contract(DIAMOND, tbaFacetAbi, provider);

  // Get TBA address
  const tbaAddress = await diamond.computeTBAAddress(tokenId);
  console.error(`TBA: ${tbaAddress}`);

  // Load session wallet
  const sessionWallet = await loadSessionWallet(label);
  console.error(`Session key: ${sessionWallet.address}`);

  // Build calldata for rollYieldToPosition
  const coder = AbiCoder.defaultAbiCoder();
  const data = coder.encode(['uint256', 'uint256'], [BigInt(tokenId), BigInt(poolId)]);

  const selector = keccak256(toUtf8Bytes('rollYieldToPosition(uint256,uint256)')).slice(0, 10);
  const calldata = selector + data.slice(2);

  // Execute through TBA
  const result = await executeWithRuntimeValidation({
    rpcUrl: rpc,
    tbaAddress,
    moduleAddress: SESSION_KEY_MODULE,
    entityId: 7,
    data: calldata,
    value: 0n,
    sessionWallet,
    chainId: parseInt(chainId)
  });

  console.log(JSON.stringify({
    success: true,
    tokenId,
    poolId,
    tbaAddress,
    result
  }, null, 2));
}

main().catch(e => {
  console.error(JSON.stringify({ error: e.message, stack: e.stack }));
  process.exit(1);
});
