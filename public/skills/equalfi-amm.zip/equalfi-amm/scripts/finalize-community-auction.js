#!/usr/bin/env node
const { parseArgs } = require('node:util');
const { createPublicClient, http, encodeFunctionData } = require('viem');
const { loadSessionWallet, executeWithRuntimeValidation } = require('@equalfi/ski');

const SESSION_KEY_MODULE = '0x4579328ED17bF3Ba0c4e79ddbAD2Ff54E49Fdcd6';

const diamondAbi = [
  {
    name: 'finalizeCommunityAuction',
    type: 'function',
    stateMutability: 'nonpayable',
    inputs: [{ name: 'auctionId', type: 'uint256' }],
    outputs: [],
  },
];

async function main() {
  const { values } = parseArgs({
    options: {
      'token-id': { type: 'string' },
      'auction-id': { type: 'string' },
      'rpc': { type: 'string' },
      'chain-id': { type: 'string' },
      help: { type: 'boolean', short: 'h' },
    },
  });

  if (values.help) {
    console.log(`Usage: node finalize-community-auction.js --token-id <id> --auction-id <id> --rpc <url> --chain-id <id>

Finalize a community auction via session key.

Options:
  --token-id <id>      Position NFT token ID
  --auction-id <id>    Community auction ID to finalize
  --rpc <url>          RPC endpoint
  --chain-id <id>      Chain ID (84532, 11155111, 421614)
  -h, --help           Show this help
`);
    process.exit(0);
  }

  const tokenId = values['token-id'];
  const auctionId = values['auction-id'];
  const rpcUrl = values.rpc;
  const chainId = parseInt(values['chain-id'] || '84532');

  if (!tokenId || !auctionId || !rpcUrl) {
    console.error('Error: --token-id, --auction-id, and --rpc are required');
    process.exit(1);
  }

  const publicClient = createPublicClient({ transport: http(rpcUrl) });
  const wallet = await loadSessionWallet(`position-${tokenId}`);

  const tbaAddress = await publicClient.readContract({
    address: '0x027c9ba58be0af69c990da55630d9042d067652b',
    abi: [{ name: 'computeTBAAddress', type: 'function', stateMutability: 'view', inputs: [{ name: 'tokenId', type: 'uint256' }], outputs: [{ name: '', type: 'address' }] }],
    functionName: 'computeTBAAddress',
    args: [BigInt(tokenId)],
  });

  const calldata = encodeFunctionData({
    abi: diamondAbi,
    functionName: 'finalizeCommunityAuction',
    args: [BigInt(auctionId)],
  });

  const txHash = await executeWithRuntimeValidation({
    rpcUrl,
    tbaAddress,
    moduleAddress: SESSION_KEY_MODULE,
    entityId: 7,
    data: calldata,
    value: 0n,
    sessionWallet: wallet,
    chainId,
  });

  console.log(JSON.stringify({ success: true, txHash, auctionId }, null, 2));
}

main().catch((err) => {
  console.error(JSON.stringify({ success: false, error: err.message }, null, 2));
  process.exit(1);
});
