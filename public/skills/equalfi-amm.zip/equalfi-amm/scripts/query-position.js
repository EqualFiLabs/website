#!/usr/bin/env node
/**
 * Query position state from EqualFi Diamond
 * 
 * Usage:
 *   node query-position.js --token-id <id> --pool-id <id> --rpc <url>
 * 
 * Outputs JSON with position state (principal, yield, debt, solvency, etc.)
 */

const { JsonRpcProvider, Contract } = require('ethers');

const DIAMOND = '0x027c9ba58be0af69c990da55630d9042d067652b';

const positionViewFacetAbi = [
  {
    name: 'getPositionState',
    type: 'function',
    stateMutability: 'view',
    inputs: [
      { name: 'tokenId', type: 'uint256' },
      { name: 'pid', type: 'uint256' }
    ],
    outputs: [
      {
        name: '',
        type: 'tuple',
        components: [
          { name: 'tokenId', type: 'uint256' },
          { name: 'poolId', type: 'uint256' },
          { name: 'underlying', type: 'address' },
          { name: 'principal', type: 'uint256' },
          { name: 'accruedYield', type: 'uint256' },
          { name: 'feeIndexCheckpoint', type: 'uint256' },
          { name: 'maintenanceIndexCheckpoint', type: 'uint256' },
          { name: 'externalCollateral', type: 'uint256' },
          { name: 'rollingLoan', type: 'tuple', components: [
            { name: 'principal', type: 'uint256' },
            { name: 'principalRemaining', type: 'uint256' },
            { name: 'openedAt', type: 'uint40' },
            { name: 'lastPaymentTimestamp', type: 'uint40' },
            { name: 'lastAccrualTs', type: 'uint40' },
            { name: 'apyBps', type: 'uint16' },
            { name: 'missedPayments', type: 'uint8' },
            { name: 'paymentIntervalSecs', type: 'uint32' },
            { name: 'depositBacked', type: 'bool' },
            { name: 'active', type: 'bool' },
            { name: 'principalAtOpen', type: 'uint256' }
          ]},
          { name: 'fixedLoanIds', type: 'uint256[]' },
          { name: 'totalDebt', type: 'uint256' },
          { name: 'solvencyRatio', type: 'uint256' },
          { name: 'isDelinquent', type: 'bool' },
          { name: 'eligibleForPenalty', type: 'bool' }
        ]
      }
    ]
  }
];

const multiPoolViewAbi = [
  {
    name: 'getPositionPoolMemberships',
    type: 'function',
    stateMutability: 'view',
    inputs: [{ name: 'tokenId', type: 'uint256' }],
    outputs: [
      {
        name: '',
        type: 'tuple[]',
        components: [
          { name: 'poolId', type: 'uint256' },
          { name: 'underlying', type: 'address' },
          { name: 'isMember', type: 'bool' },
          { name: 'hasBalance', type: 'bool' },
          { name: 'hasActiveLoans', type: 'bool' }
        ]
      }
    ]
  }
];

function parseArgs() {
  const args = process.argv.slice(2);
  const flags = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) {
      const key = args[i].slice(2).replace(/-([a-z])/g, (_, c) => c.toUpperCase());
      flags[key] = args[++i];
    }
  }
  return flags;
}

async function main() {
  const { tokenId, poolId, rpc } = parseArgs();

  if (!rpc) {
    console.error(JSON.stringify({ error: 'Missing --rpc' }));
    process.exit(1);
  }

  const provider = new JsonRpcProvider(rpc);
  const diamond = new Contract(DIAMOND, [...positionViewFacetAbi, ...multiPoolViewAbi], provider);

  const result = { tokenId, poolId };

  // Get pool memberships if tokenId provided
  if (tokenId) {
    try {
      result.memberships = await diamond.getPositionPoolMemberships(tokenId);
    } catch (e) {
      result.membershipsError = e.message;
    }

    // Get position state if both tokenId and poolId provided
    if (poolId) {
      try {
        const state = await diamond.getPositionState(tokenId, poolId);
        result.state = {
          principal: state.principal.toString(),
          accruedYield: state.accruedYield.toString(),
          totalDebt: state.totalDebt.toString(),
          solvencyRatio: state.solvencyRatio.toString(),
          isSolvent: state.solvencyRatio >= 10000,
          isDelinquent: state.isDelinquent,
          hasActiveLoan: state.rollingLoan?.active || state.fixedLoanIds?.length > 0
        };
      } catch (e) {
        result.stateError = e.message;
      }
    }
  }

  console.log(JSON.stringify(result, null, 2));
}

main().catch(e => {
  console.error(JSON.stringify({ error: e.message }));
  process.exit(1);
});
